<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'hutech_environment' );

/** MySQL database username */
define( 'DB_USER', 'admin' );

/** MySQL database password */
define( 'DB_PASSWORD', 'admin' );

/** MySQL hostname */
define( 'DB_HOST', 'database' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', 'utf8mb4_unicode_ci' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'dC;)+`#$&FAPoCf2neo_h7xhET8;BDt/)PFCvm`eN:h_-d/g,r[=b>r;;VZNDD|~' );
define( 'SECURE_AUTH_KEY',   'U6diZ|?]F]-Z:ZuZ%JzlQ;0NK`M!?vudk~?kkTe)KET,.Z-OAu8q{c4&e()0Y H_' );
define( 'LOGGED_IN_KEY',     'H~Yi:6-&&>R:Ig.Os,+u~6vlF/-.[wbw!dqc)%(X)v`|y5D qS`1vP0cA:a}WG<l' );
define( 'NONCE_KEY',         '9b}>z6KkYg^0Z@vAAQr{Pc!z:oF>7Z]~`KE7)spJOC,:ui}+5m2:aEA:qY=5P{6o' );
define( 'AUTH_SALT',         'k=_VPEMTFEqM3LnEQjJJTqJ@zGm{5eXya9B5ryRiSzxm =Jz/ KX2eDtvh4zM%5a' );
define( 'SECURE_AUTH_SALT',  '7#TF/O+Ix9KP|tJ]u&@&UguE+K8r8+qsbZo8Rh?Nxe)31]Ak6faX4+io*Xg8R2}I' );
define( 'LOGGED_IN_SALT',    '~%,|]m Ub-[`:G}SQ+ww}=4:FP.b9I$civW*s.t Z|C$TQhS:jRRa@+&!_?) t,l' );
define( 'NONCE_SALT',        'B Tk.M|bd*.y|ywTwDCk?a/[OjFwPHOIH}2*WO5^VHwfFl9Pv=-K:9]VJ4B$hX{F' );
define( 'WP_CACHE_KEY_SALT', 'g)xsKNsD$*5E>OGY4N_W-bL+g}/!(;<KxD#HMa;>j5HwCu;$Sr9):^`2b-+OcVIN' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


define( 'FS_METHOD', 'direct' );
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_DISPLAY', true );


/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
