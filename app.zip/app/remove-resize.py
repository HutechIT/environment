#!/usr/bin/env python3

from os import walk, remove
from re import match

for base_path, dirs, files in walk('wp-content/uploads'):
    for file in files:
        if match(r'.*-[0-9]+x[0-9]+\.(jpg|png)*', file):
            path = f'{base_path}/{file}'
            print(path)
            remove(path)
