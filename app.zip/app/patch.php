<?php
require_once 'wp-config.php';

define('ORIGIN_DOMAIN', 'environment.hutech.dev');
define('NEW_DOMAIN', 'trash40.tk');

function fix_domain($value)
{
    switch (gettype($value)) {
        case 'array':
            foreach ($value as $key => $item) {
                $value[$key] = fix_domain($item);
            }
            break;
        case 'string':
            if (strpos($value, ORIGIN_DOMAIN) !== false) {
                return str_replace(ORIGIN_DOMAIN, NEW_DOMAIN, $value);
            }
            break;
        case 'object':
            $reflection = new ReflectionObject($value);
            foreach ($reflection->getProperties() as $property) {
                $property->setAccessible(true);
                $property->setValue($value, fix_domain($property->getValue($value)));
            }
            break;
        case 'integer':
        case 'boolean':
            break;
        default:
            var_dump(gettype($value));
    }
    return $value;
}

foreach ([
             'siteurl',
             'home',
             'pix_options',
             'pix_options-transients',
             'pixfort_site_theme_url',
             'pix_essentials_style_url',
             'elementor_log',
         ] as $key) {
    $option = get_option($key);
    $option = fix_domain($option);
    update_option($key, $option);
}

foreach (get_users() as $user) {
    $user->user_url = fix_domain($user->user_url);
    wp_update_user($user);
}

global $wpdb;
foreach ($wpdb->get_results('SELECT `id` FROM `wp_posts`') as $record) {
    $post = get_post($record->id);
    $post->post_content = fix_domain($post->post_content);
    $post->guid = fix_domain($post->guid);
    wp_update_post($post);
    $wpdb->query('UPDATE `wp_posts` SET `guid` = "' . $post->guid . '" WHERE `wp_posts`.`ID` = ' . $post->ID);
}